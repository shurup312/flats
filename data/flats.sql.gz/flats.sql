-- Adminer 3.2.0 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `cities`;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `cities` (`id`, `name`) VALUES
(1,	'Москва'),
(2,	'Апрелевка'),
(3,	'Балашиха'),
(4,	'Бронницы');

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL DEFAULT '0' COMMENT '0 - к квартире',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_comments_users` (`user_id`),
  CONSTRAINT `FK_comments_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `flats`;
CREATE TABLE `flats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `metro_id` int(11) DEFAULT NULL,
  `street_id` int(11) NOT NULL,
  `num_house` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `num_flat` smallint(6) NOT NULL,
  `type_id` int(11) NOT NULL DEFAULT '0' COMMENT '0 - к квартире',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `user_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `rooms_total` int(11) NOT NULL DEFAULT '0' COMMENT '0 - комната, 1 и далее - количество комнат в квартире',
  `rooms_offer` smallint(6) NOT NULL DEFAULT '0',
  `rooms_type` smallint(6) NOT NULL DEFAULT '0' COMMENT '0 - смежные, 1 - раздельные',
  `is_called` tinyint(1) NOT NULL DEFAULT '0',
  `far_minutes` smallint(6) NOT NULL DEFAULT '0',
  `far_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 - пешком, 2 - на транспорте',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 - квартира, 2 - дом',
  `area_total` float NOT NULL DEFAULT '0',
  `area_live` float NOT NULL DEFAULT '0',
  `area_kitchen` float NOT NULL DEFAULT '0',
  `cost` float NOT NULL DEFAULT '0',
  `cost_market` float NOT NULL DEFAULT '0',
  `currency_id` int(11) NOT NULL DEFAULT '1',
  `is_insurance` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'Вносит ли человек страховой депозит',
  `floor_num` smallint(6) DEFAULT NULL,
  `floor_total` smallint(6) DEFAULT NULL,
  `is_furnitured_rooms` tinyint(1) DEFAULT NULL,
  `is_furnitures_kitchen` tinyint(1) DEFAULT NULL,
  `is_tv` tinyint(1) DEFAULT NULL,
  `is_refrigerator` tinyint(1) DEFAULT NULL,
  `is_washer` tinyint(1) DEFAULT NULL,
  `is_phone` tinyint(1) DEFAULT NULL,
  `is_balcony` tinyint(1) DEFAULT NULL,
  `is_animal` tinyint(1) DEFAULT NULL,
  `is_child` tinyint(1) DEFAULT NULL,
  `is_on_main` tinyint(1) DEFAULT NULL,
  `is_liquidity` tinyint(1) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_flats_users` (`user_id`),
  KEY `FK_flats_metro` (`metro_id`),
  KEY `FK_flats_owners` (`owner_id`),
  KEY `FK_flats_streets` (`street_id`),
  CONSTRAINT `FK_flats_streets` FOREIGN KEY (`street_id`) REFERENCES `streets` (`id`),
  CONSTRAINT `FK_flats_metro` FOREIGN KEY (`metro_id`) REFERENCES `metro` (`id`),
  CONSTRAINT `FK_flats_owners` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`id`),
  CONSTRAINT `FK_flats_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `flats_images`;
CREATE TABLE `flats_images` (
  `flat_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL,
  PRIMARY KEY (`flat_id`,`image_id`),
  KEY `FK_flats_images_images` (`image_id`),
  CONSTRAINT `FK_flats_images_images` FOREIGN KEY (`image_id`) REFERENCES `images` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_flats_images_flats` FOREIGN KEY (`flat_id`) REFERENCES `flats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `flats_phones`;
CREATE TABLE `flats_phones` (
  `flat_id` int(11) NOT NULL,
  `phone_id` int(11) NOT NULL,
  PRIMARY KEY (`flat_id`,`phone_id`),
  KEY `FK_flats_phones_phones` (`phone_id`),
  CONSTRAINT `FK_flats_phones_phones` FOREIGN KEY (`phone_id`) REFERENCES `phones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_flats_phones_flats` FOREIGN KEY (`flat_id`) REFERENCES `flats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `images`;
CREATE TABLE `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `metro`;
CREATE TABLE `metro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `migration`;
CREATE TABLE `migration` (
  `version` varchar(180) COLLATE utf8_bin NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base',	1415521237),
('m141107_061144_create_users_table',	1415521240),
('m141107_073015_create_cities_table',	1415521240),
('m141107_073702_create_comments_table',	1415521240),
('m141107_080116_create_flats_table',	1415521240),
('m141107_093310_create_metro_table',	1415521241),
('m141107_112321_create_images_table',	1415521241),
('m141107_113225_create_owners_table',	1415521241),
('m141107_113755_create_phones_table',	1415521241),
('m141107_114240_create_streets_table',	1415521242),
('m141108_182219_create_flats_images_table',	1415521243),
('m141108_183002_create_flats_phones_table',	1415521244);

DROP TABLE IF EXISTS `owners`;
CREATE TABLE `owners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Имя',
  `middle_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Отчество',
  `last_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Фамилия',
  `age` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `phones`;
CREATE TABLE `phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `type_id` smallint(6) NOT NULL DEFAULT '0' COMMENT '1 - квартиры, 2 - пользователи, 3 - собственники',
  `phone` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `streets`;
CREATE TABLE `streets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_streets_cities` (`city_id`),
  CONSTRAINT `FK_streets_cities` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `streets` (`id`, `city_id`, `name`) VALUES
(1,	1,	'Лазурная'),
(2,	1,	'Кирова'),
(3,	2,	'пр. Ленина'),
(4,	2,	'Победы'),
(5,	3,	'Речная'),
(6,	3,	'Горная'),
(7,	4,	'Лесная'),
(8,	4,	'Тимофеева');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` smallint(6) NOT NULL DEFAULT '0',
  `first_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Имя',
  `middle_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Отчество',
  `last_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0' COMMENT 'Фамилия',
  `status` smallint(6) NOT NULL DEFAULT '0',
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `users` (`id`, `username`, `email`, `role`, `first_name`, `middle_name`, `last_name`, `status`, `auth_key`, `password_hash`, `password_reset_token`, `date_created`, `date_updated`) VALUES
(1,	'admin',	'admin@flats.com',	0,	'Admin',	'Admin',	'Admin',	0,	'iZGcCXYh-YgfL6SfQKZFG3jIm2d2v_jw',	'$2y$13$A3XTeg1Pdu1NZ3w3/R6MS.jJ66AouaTF3oRITXFeUIi1pYVl6VqUa',	NULL,	'2014-11-09 11:20:40',	'2014-11-09 11:20:40');

-- 2014-11-09 13:15:43
